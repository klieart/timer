console.log('The timer JS file loaded');
